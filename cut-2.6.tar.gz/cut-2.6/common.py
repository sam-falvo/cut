#!/usr/bin/python


def typeOf(obj):
    return type(obj).__name__

